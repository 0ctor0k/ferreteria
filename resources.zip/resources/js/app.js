import './bootstrap';
import { createApp } from 'vue';
import App from '@/pages/App.vue'

createApp(App).mount('#app')